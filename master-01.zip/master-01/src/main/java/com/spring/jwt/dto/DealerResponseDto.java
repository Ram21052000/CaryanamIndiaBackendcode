package com.spring.jwt.dto;

public class DealerResponseDto {
    public String address;
    public String adharShopact;
    public String area;
    public String city;
    public String firstName;
    public String lastName;
    public String mobileNo;
    public String shopName;
    public String email;
    private Integer dealer_id;
}
