package com.spring.jwt.premiumCar.PremiunCarBrandData;

import lombok.Data;

@Data
public class PremiunCarBrandDataDto {

    private Integer premiunBrandDataId;
    private String brand;
    private String variant;
    private String subVariant;
}
