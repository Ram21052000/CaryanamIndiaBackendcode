package com.spring.jwt.Color;



public class DuplicateColorException extends RuntimeException {
    public DuplicateColorException(String message) {
        super(message);
    }
}
