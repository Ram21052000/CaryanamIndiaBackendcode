package com.spring.jwt.exception;

public class DealerDeatilsNotFoundException extends RuntimeException{
    public DealerDeatilsNotFoundException(String message) {
        super(message);
    }
}
