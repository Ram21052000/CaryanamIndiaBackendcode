package com.spring.jwt.exception;

public class PlacedBidNotFoundExceptions extends RuntimeException{
    public PlacedBidNotFoundExceptions(String s) {
    }
}
