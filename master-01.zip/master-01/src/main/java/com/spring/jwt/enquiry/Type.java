package  com.spring.jwt.enquiry;

public enum Type {

    SERVICE,
    NONSERVICE;
}
