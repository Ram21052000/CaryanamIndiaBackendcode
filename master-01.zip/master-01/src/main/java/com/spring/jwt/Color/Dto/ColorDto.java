package com.spring.jwt.Color.Dto;


import lombok.Data;

@Data
public class ColorDto {

    private Integer ColorId;

    private String name;
}
