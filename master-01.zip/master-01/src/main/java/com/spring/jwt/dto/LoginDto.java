package com.spring.jwt.dto;

public class LoginDto {
    public String mobileNo;
    public String email;
    public String password;
}
