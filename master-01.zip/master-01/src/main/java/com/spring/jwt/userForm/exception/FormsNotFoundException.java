package com.spring.jwt.userForm.exception;

public class FormsNotFoundException extends RuntimeException {
    public FormsNotFoundException(String message) {
        super(message);
    }
}
