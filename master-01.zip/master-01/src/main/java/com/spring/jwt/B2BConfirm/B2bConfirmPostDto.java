package com.spring.jwt.B2BConfirm;

import lombok.Data;

@Data
public class B2bConfirmPostDto {

    private Integer b2BId;

    private String price;

}
