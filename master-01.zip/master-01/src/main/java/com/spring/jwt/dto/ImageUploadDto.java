package com.spring.jwt.dto;

import lombok.Data;

@Data
public class ImageUploadDto {

    private String message;
    private String exception;
}
