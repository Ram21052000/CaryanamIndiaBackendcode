package com.spring.jwt.exception;

public class BidNotFoundExceptions extends RuntimeException {
    public BidNotFoundExceptions(String bookingNotFound) {
    }
}
