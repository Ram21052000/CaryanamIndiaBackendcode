package com.spring.jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtWithSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
